<link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css"/>


    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.pt-BR.js">
    </script>
<div id="main-content" class="clearfix">
    <div id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="icon-home"></i>
                <a href="<?php echo site_url();?>">Home</a>

                <span class="divider">
                    <i class="icon-angle-right"></i>
                </span>
            </li>

            <li>
                <a href="<?php echo site_url('collector_types');?>">Student</a>

                <span class="divider">
                    <i class="icon-angle-right"></i>
                </span>
            </li>
            <li class="active"><?php if($action == 'edit'){?>Edit<?php }else{?>Add<?php }?></li>
        </ul><!--.breadcrumb-->

        <!--<div id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="input-small search-query" id="nav-search-input" autocomplete="off" />
                    <i class="icon-search" id="nav-search-icon"></i>
                </span>
            </form>
        </div>--><!--#nav-search-->
    </div>

    <div id="page-content" class="clearfix">
        

        <div class="row-fluid">
            <!--PAGE CONTENT BEGINS HERE-->

            <div class="row-fluid">
                <div class="span12">
                    <div class="widget-box">
                        

                        <div class="widget-body">
                            <div class="widget-main">
                                <div class="row-fluid">
                                    <div class="step-content row-fluid position-relative">
                                        <div class="step-pane active" id="step1">
                                          
											
                                            <?php if(validation_errors()){?>
                                            <div class="errorSummary"><p>Please fix the following input errors:</p>
                                                <ul>
                                               		<?php echo validation_errors('<li>', '</li>'); ?>
                                                </ul>
                                            </div>
                                            <?php }?>
                                            <form class="form-horizontal"  method="post" action="" name="frm">
                                            	   <table style="width:100%">
      
        <tr>
             <td colspan="3" style="color: red; font-size: 18px" height="25" align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Basic Student Information<span class="red12">*</span></td>
                 
        </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#E4EDE4">
      <table width="100%" border="0" cellpadding="5" cellspacing="0" class="black14">
          
        <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="teacher_short_name">Registration No </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="registration_no" name="registration_no" class="span6"  value="<?php echo $row['registration_no']?>">
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="student_name">Resource Person  </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="student_name" name="student_name" class="span6" value="<?php echo $row['student_name']?>"">
                                                       
                                                    </div>
                                                </div>
            </td>
            <td>
                     <div class="control-group">
                                                    <label class="control-label" for="defaults">Father's Name </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="father_name" name="father_name" class="span6" value="<?php echo $row['father_name']?>"">
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="mother_name">Mother's Name </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="mother_name" name="mother_name" class="span6" value="<?php echo $row['mother_name']?>"">
                                                       
                                                    </div>
                                                </div>
            </td>
            </td>
        </tr>
    
      
        
    
      </table>
    </td>
  </tr>
                <tr>
             <td colspan="3" style="color: red; font-size: 18px" height="25" align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Admit Course Information<span class="red12">*</span></td>
                 
        </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#E4EDE4">
      <table width="100%" border="0" cellpadding="5" cellspacing="0" class="black14">
          
        <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="course_id">Course </label>

                                                   <div class="controls">
                                                      <select style="width:300px" id="course_id" name="course_id" class="span4">
                                                       		<option value="">Select</option>
                                                            <?php foreach($courses as $course){?>
                                                            <option value="<?php echo $course->id;?>" <?php if($course->id == $row['course_id']){?> selected="selected"<?php }?>><?php echo $course->course_name;?></option>
                                                            
                                                            <?php }?>
                                                       </select>
                                                    </div>
                                                </div>
               
            </td>
            <td>
                     <div class="control-group">
                                                    <label class="control-label" for="admission_organization_by">
Admission Organization By
</label>

                                                   
                                                       <div class="controls">
                                                      <select style="width:300px" id="organization_id" name="organization_id" class="span4">
                                                       		<option value="">Select</option>
                                                            <?php foreach($organizations as $organization){?>
                                                            <option value="<?php echo $organization->id;?>" <?php if($organization->id == $row['organization_id']){?> selected="selected"<?php }?>><?php echo $organization->organization_name;?></option>
                                                            
                                                            <?php }?>
                                                       </select>
                                                    </div>
                                                       
                                                  
                                                </div>
       
            </td>
            </td>
        </tr>
           <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="course_id">Registration Fee </label>

                                                
                                                      <div class="controls">
                                                         <input type="text" style="width:300px" id="registration_fee" name="registration_fee" class="span6" value="<?php echo $row['registration_fee']?>">
                                                       
                                             
                                                    </div>
                                                </div>
               
            </td>
          
        </tr>
   
      
        
    
      </table>
    </td>
  </tr>
        
        <tr>
             <td colspan="3" style="color: red; font-size: 18px" height="25" align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Office Information<span class="red12">*</span></td>
                 
        </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#E4EDE4">
      <table width="100%" border="0" cellpadding="5" cellspacing="0" class="black14">
          
        <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="organization_id">Organization</label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="organization_id" name="organization_id" class="span6" value="<?php echo $row['organization_id']?>"">
                                                       Contact No

                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="total_experience">	Total Experience </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="total_experience" name="total_experience" class="span6" value="<?php echo $row['total_experience']?>"">
                                                       
                                                    </div>
                                                </div>
            </td>
            <td>
                     <div class="control-group">
                                                    <label class="control-label" for="teacher_short_name">Current Employeement </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="current_employeement" name="current_employeement" class="span6" value="<?php echo $row['current_employeement']?>"">
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="defaults">Current Employeement Address </label>

                                                    <div class="controls">
                                                        <textarea id="current_employeement_address" style="width:300px; height:100px"name="current_employeement_address" class="span6"><?php echo $row['current_employeement_address']?></textarea>
                                                         
                                                       
                                                    </div>
                                                </div>
            </td>
            </td>
        </tr>
   
      
        
    
      </table>
    </td>
  </tr>
          <tr>
             <td colspan="3" style="color: red; font-size: 18px" height="25" align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Personal Information<span class="red12">*</span></td>
                 
        </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#E4EDE4">
      <table width="100%" border="0" cellpadding="5" cellspacing="0" class="black14">
          
        <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="teacher_short_name">Date of Birth </label>

                                                    
                                                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <div id="datetimepicker" class="dp input-append date">
                                                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="width:270px" type="text" id="date_of_birth" name="date_of_birth" style="width:100px" value="<?php echo $row['date_of_birth']?>">
                                                    <span class="add-on">
                                                     <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i>
                                                    </span>
                                                     </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="defaults">Contact No </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="defaults" name="defaults" class="span6" value="<?php echo $row['defaults']?>">
                                                       
                                                    </div>
                                                </div>
            </td>
            <td>
                     <div class="control-group">
                                                    <label class="control-label" for="teacher_short_name">Mobile No </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="student_name" name="Mobile_no" class="span6" value="<?php echo $row['student_name']?>"">
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="defaults">Email </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="defaults" name="defaults" class="span6" value="<?php echo $row['defaults']?>"">
                                                       
                                                    </div>
                                                </div>
            </td>
            </td>
        </tr>
        <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="gender">Gender </label>

                                                    <div class="controls">
                                                            <select style="width:300px" id="gender" name="gender" class="span4">
                                                       		<option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                                  <option value="Others">Others</option>
                                                            
                                                       </select>
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="defaults">Religion </label>

                                                    <div class="controls">
                                                          <select style="width:300px" id="gender" name="religion" class="span4">
                                                       		<option value="Islam">Islam</option>
                                                                <option value="Hindu">Hindu</option>
                                                                  <option value="Crishtan">Crishtan</option>
                                                                   <option value="Others">Others</option>
                                                            
                                                       </select>
                                                       
                                                    </div>
                                                </div>
            </td>
            <td>
       <div class="control-group">
                                                    <label class="control-label" for="country">Country </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="country" name="country" class="span6" value="<?php echo $row['student_name']?>"">
                                                       
                                                    </div>
                                                </div>
                <div class="control-group">
                                                    <label class="control-label" for="nationality">Nationality </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="nationality" name="nationality" class="span6" value="<?php echo $row['nationality']?>"">
                                                       
                                                    </div>
                                                </div>
            </td>
        </tr>
         <tr>
            <td>
                <div class="control-group">
                                                    <label class="control-label" for="gender">Marital Status </label>

                                                    <div class="controls">
                                                            <select style="width:300px" id="marital_statud" name="gender" class="span4">
                                                       		<option value="Male">Marid</option>
                                                                <option value="Female">Unmarid</option>
                                                              
                                                            
                                                       </select>
                                                       
                                                    </div>
                                                </div>
              
            </td>
            <td>
       <div class="control-group">
                                                    <label class="control-label" for="country">National ID  </label>

                                                    <div class="controls">
                                                         <input type="text" style="width:300px" id="country" name="country" class="span6" value="<?php echo $row['student_name']?>"">
                                                       
                                                    </div>
                                                </div>
               
            </td>
        </tr>
      
        
    
      </table>
    </td>
  </tr>
  
  
  
  <tr>
          <td colspan="3" align="left" valign="middle" bgcolor="#D8E7D8" class="black14">
              <table width="102.50%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="50%" align="left" valign="middle" class="bdr02">
                  <table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                <tr>
                  <td td height="25" colspan="2" align="left" style="color: red; font-size: 18px" valign="top" bgcolor="#ADC9AD" class="black14">Present Address<span class="red12">*</span></td>
                </tr>
				
                <tr>
                  <td align="left" valign="middle">
				  Village/Town/<br />
                  Road/House/Flat</td>
                  <td  align="left" valign="middle">
                    <textarea style="width:300px" name="Member[pre_address]"></textarea>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="middle">District</td>
                   <td align="left" valign="middle" bgcolor="#E4EDE4"> 
                   
                        <select style="width: 300px;" name="Member[pre_district]" id="Member_pre_district">
<option value="">Select District</option>
<option value="Satkhira">Satkhira</option>
<option value="Narail">Narail</option>
<option value="Meherpur">Meherpur</option>
<option value="Magura">Magura</option>
<option value="Kustia">Kustia</option>
<option value="Khulna">Khulna</option>
<option value="Jhenaidah">Jhenaidah</option>
<option value="Jessore">Jessore</option>
<option value="Chuadanga">Chuadanga</option>
<option value="Bagerhat">Bagerhat</option>
</select>   
                       
                   
                   </td>
                </tr>
                <tr>
                  <td align="left" valign="top">P.S./Upazila <img src="images/loader.gif" border="0" align="absmiddle" name ="loading1" style="visibility:hidden"/></td>
                  <td align="left" valign="middle" bgcolor="#E4EDE4"> <select style="width: 300px;" name="Member[pre_up]" id="Member_pre_up">
<option value="">Select Thana</option>
<option value="" selected="selected"></option>
<option value="Satkhira-s">Satkhira-s</option>
<option value="Assasuni">Assasuni</option>
<option value="Kalaroa">Kalaroa</option>
<option value="Kaliganj">Kaliganj</option>
<option value="Debhata">Debhata</option>
<option value="Shyamnagar">Shyamnagar</option>
<option value="tala">tala</option>
<option value="Lohagara">Lohagara</option>
<option value="kalia">kalia</option>
<option value="Narail-s">Narail-s</option>
<option value="Gangni">Gangni</option>
<option value="Mujib nagar">Mujib nagar</option>
<option value="Meherpur-s">Meherpur-s</option>
<option value="Mohammadpur">Mohammadpur</option>
<option value="Magura-s ">Magura-s </option>
<option value="Salikha">Salikha</option>
<option value="Sreepur ">Sreepur </option>
<option value="Daulatpur">Daulatpur</option>
<option value="Khoksha">Khoksha</option>
<option value="Bheramara">Bheramara</option>
<option value="Kumarkhali">Kumarkhali</option>
<option value="Mirpur">Mirpur</option>
<option value="Kushtia-s">Kushtia-s</option>
<option value="Batiaghata">Batiaghata</option>
<option value="Dighalia">Dighalia</option>
<option value="Dumuria">Dumuria</option>
<option value="Paikgacha">Paikgacha</option>
<option value="Phultala">Phultala</option>
<option value="Terokhada">Terokhada</option>
<option value="Rupsa">Rupsa</option>
<option value="Koira">Koira</option>
<option value="Dacope ">Dacope </option>
<option value="moheshpur">moheshpur</option>
<option value="kotchandpur">kotchandpur</option>
<option value="Shailkupa">Shailkupa</option>
<option value="Harinakunda">Harinakunda</option>
<option value="Jhenaidah-s ">Jhenaidah-s </option>
<option value="Monirampur">Monirampur</option>
<option value="Jessore-s">Jessore-s</option>
<option value="Keshabpur">Keshabpur</option>
<option value="Jhikargacha">Jhikargacha</option>
<option value="Chowgacha ">Chowgacha </option>
<option value="Bagherpara">Bagherpara</option>
<option value="Abhoynagar">Abhoynagar</option>
<option value="Sarsha">Sarsha</option>
<option value="Alamdanga">Alamdanga</option>
<option value="Jibannagar">Jibannagar</option>
<option value="Damurhuda">Damurhuda</option>
<option value="Chuadanga-s ">Chuadanga-s </option>
<option value="Rampal">Rampal</option>
<option value="Morrelganj ">Morrelganj </option>
<option value="Bagerhat-s">Bagerhat-s</option>
<option value="Fakirhat">Fakirhat</option>
<option value="Kachua">Kachua</option>
<option value="Mollahat">Mollahat</option>
<option value="Sharankhola">Sharankhola</option>
<option value="Chitalmari">Chitalmari</option>
<option value="Mongla">Mongla</option>
</select></td>
                </tr>
                <tr>
                  <td align="left" valign="middle">Post Office</td>
                  <td align="left" valign="middle">
                    <input name="Member[pre_post_office]" style="width:300px" type="text" class="textfield06" id="present_post" onkeypress="return alpha(event,letters)" />
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="middle">Post Code</td>
                  <td align="left" valign="middle">
                    <input name="Member[pre_post_code]"  style="width:300px" type="text" class="textfield06" id="present_pcode" onkeypress="return alpha(event,numbers)" />
                  </td>
                </tr>
               
              </table></td>
              <td width="1%" align="left" valign="middle">&nbsp;</td>
              <td width="100%" align="left" valign="middle" class="bdr02"><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                <tr>
                  <td td height="25" colspan="2" align="left" style="color: red; font-size: 18px" valign="middle" bgcolor="#ADC9AD" class="black14">Permanent Address<span class="red12"></span> <span class="black11i"></span></td>
                </tr>
				
                <tr>
                  <td align="left" valign="middle">
				  Village/Town/<br />
                  Road/House/Flat</td>
                  <td style="width:300px" align="left" valign="middle">
                    <textarea  style="width:300px" name="Member[per_addrress]" cols="45" rows="2" class="textfield06" id="permanent_vill" onkeypress="return alpha(event,letters+numbers+custom)"></textarea>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="middle">Home District</td>
                  <td align="left" valign="middle" bgcolor="#E4EDE4"> <select style="width: 300px;" name="Member[per_district]" id="Member_per_district">
<option value="">Select District</option>
<option value="Satkhira">Satkhira</option>
<option value="Narail">Narail</option>
<option value="Meherpur">Meherpur</option>
<option value="Magura">Magura</option>
<option value="Kustia">Kustia</option>
<option value="Khulna">Khulna</option>
<option value="Jhenaidah">Jhenaidah</option>
<option value="Jessore">Jessore</option>
<option value="Chuadanga">Chuadanga</option>
<option value="Bagerhat">Bagerhat</option>
</select></td>
                </tr>
                <tr>
                  <td align="left" valign="top">P.S./Upazila <img src="images/loader.gif" border="0" align="absmiddle" name ="loading2" style="visibility:hidden"/></td>
                  <td align="left" valign="middle" bgcolor="#E4EDE4"> <select style="width: 300px;" name="Member[per_up]" id="Member_per_up">
<option value="">Select District</option>
<option value="" selected="selected"></option>
<option value="Satkhira-s">Satkhira-s</option>
<option value="Assasuni">Assasuni</option>
<option value="Kalaroa">Kalaroa</option>
<option value="Kaliganj">Kaliganj</option>
<option value="Debhata">Debhata</option>
<option value="Shyamnagar">Shyamnagar</option>
<option value="tala">tala</option>
<option value="Lohagara">Lohagara</option>
<option value="kalia">kalia</option>
<option value="Narail-s">Narail-s</option>
<option value="Gangni">Gangni</option>
<option value="Mujib nagar">Mujib nagar</option>
<option value="Meherpur-s">Meherpur-s</option>
<option value="Mohammadpur">Mohammadpur</option>
<option value="Magura-s ">Magura-s </option>
<option value="Salikha">Salikha</option>
<option value="Sreepur ">Sreepur </option>
<option value="Daulatpur">Daulatpur</option>
<option value="Khoksha">Khoksha</option>
<option value="Bheramara">Bheramara</option>
<option value="Kumarkhali">Kumarkhali</option>
<option value="Mirpur">Mirpur</option>
<option value="Kushtia-s">Kushtia-s</option>
<option value="Batiaghata">Batiaghata</option>
<option value="Dighalia">Dighalia</option>
<option value="Dumuria">Dumuria</option>
<option value="Paikgacha">Paikgacha</option>
<option value="Phultala">Phultala</option>
<option value="Terokhada">Terokhada</option>
<option value="Rupsa">Rupsa</option>
<option value="Koira">Koira</option>
<option value="Dacope ">Dacope </option>
<option value="moheshpur">moheshpur</option>
<option value="kotchandpur">kotchandpur</option>
<option value="Shailkupa">Shailkupa</option>
<option value="Harinakunda">Harinakunda</option>
<option value="Jhenaidah-s ">Jhenaidah-s </option>
<option value="Monirampur">Monirampur</option>
<option value="Jessore-s">Jessore-s</option>
<option value="Keshabpur">Keshabpur</option>
<option value="Jhikargacha">Jhikargacha</option>
<option value="Chowgacha ">Chowgacha </option>
<option value="Bagherpara">Bagherpara</option>
<option value="Abhoynagar">Abhoynagar</option>
<option value="Sarsha">Sarsha</option>
<option value="Alamdanga">Alamdanga</option>
<option value="Jibannagar">Jibannagar</option>
<option value="Damurhuda">Damurhuda</option>
<option value="Chuadanga-s ">Chuadanga-s </option>
<option value="Rampal">Rampal</option>
<option value="Morrelganj ">Morrelganj </option>
<option value="Bagerhat-s">Bagerhat-s</option>
<option value="Fakirhat">Fakirhat</option>
<option value="Kachua">Kachua</option>
<option value="Mollahat">Mollahat</option>
<option value="Sharankhola">Sharankhola</option>
<option value="Chitalmari">Chitalmari</option>
<option value="Mongla">Mongla</option>
</select></td>
                </tr>
                <tr>
                  <td align="left" valign="middle">Post Office</td>
                  <td align="left" valign="middle">
                    <input name="Member[per_post_office]" style="width:300px" type="text" class="textfield06" id="permanent_post" onkeypress="return alpha(event,letters)" />
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="middle">Post Code</td>
                  <td align="left" valign="middle">
                    <input name="Member[per_post_code]" style="width:300px" type="text" class="textfield06" id="permanent_pcode" onkeypress="return alpha(event,numbers)" />
                  </td>
                </tr>
              </table></td>
              <td width="3%" align="left" valign="middle">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
          <tr>
          <td colspan="3" align="left" valign="middle" bgcolor="#D8E7D8" class="black14"><table width="102.50%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="100%" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="50%" height="30" align="left" style="color: red; font-size: 18px" valign="middle">Academic Qualifications:</td>
                  <td width="1%" height="30" align="left" valign="middle">&nbsp;</td>
                  <td width="49%" height="30" align="left" valign="middle">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" valign="top" class="bdr02"><table width="100%" border="0" cellpadding="3" cellspacing="0">
                    <tr>
                      <td height="25" bgcolor="#ADC9AD" style="color: red; font-size: 18px" class="black12bold">SSC or Equivalent Level<span class="red12">*</span></td>
                    </tr>
                    <tr>
                      <td><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                        <tr>
                          <td width="50%" align="left" valign="middle">Examination</td>
                          <td width="%" align="left" valign="middle"><select  style="width:350px" name="exam1" class="textfield06a" id="exam1">
                            <option selected="selected" value="0">Select One</option>
							<option value="1">S.S.C</option><option value="2">Dakhil</option><option value="3">S.S.C Vocational</option><option value="4">O Level/Cambridge</option><option value="5">S.S.C Equivalent</option>
                          </select></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Board</td>
                          <td align="left" valign="middle"><select style="width:350px"  name="institute1" class="textfield06a" id="institute1">
                            <option selected="selected" value="0">Select One</option>
                            <option value="1">Dhaka</option><option value="2">Comilla</option><option value="3">Rajshahi</option><option value="4">Jessore</option><option value="5">Chittagong</option><option value="6">Barisal</option><option value="7">Sylhet</option><option value="8">Dinajpur</option><option value="9">Madrasah</option><option value="10">Technical</option><option value="15">Cambridge International - IGCE</option><option value="16">Edexcel International</option><option value="20">Others</option>
                          </select></td>
                        </tr>
						 <tr>
                          <td height="25" align="left" valign="middle">Roll No</td>
                          <td height="25" align="left" valign="middle"><input style="width:350px"  name="roll1" type="text" class="textfield07b" id="roll1" onkeypress="return alpha(event,numbers)" /></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Result</td>
                          <td align="left" valign="middle"><table width="100%" border="0" cellpadding="0" cellspacing="1" class="black14" style="margin-bottom:1px;">
                            <tr>
                              <td align="left" valign="middle"><select style="width:280px"  name="result1" class="textfield07" id="result1" onchange="Show_GpaTextBox(this.id,'result_gpa1');" >
                                <option value="0" selected="selected">Select</option>
                                <option value="1">1st Division</option>
                                <option value="2">2nd Division</option>
                                <option value="3">3rd Division</option>
                                <option value="4">GPA(out of 4)</option>
								<option value="5">GPA(out of 5)</option>
                              </select>
                               <input style="width:60px"  type="text" id="gpapont"/>
                              </td>
                             
                            </tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Group</td>
                          <td align="left" valign="middle"><select style="width:350px"  name="subject1" class="textfield07" id="subject1">
                            <option selected="selected" value="0">Select One</option>
                            <option value="1">Science</option><option value="2">Humanities</option><option value="3">Commerce</option><option value="9">Others</option>
                          </select></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Passing Year</td>
                          <td align="left" valign="middle"><select style="width:350px"  name="year1" class="textfield07" id="year1">
                            <option selected="selected" value="0">Select One</option>
                            <option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option>
                          </select></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                  <td rowspan="2" align="left" valign="middle">&nbsp;</td>
                  <td align="left" valign="top" class="bdr02"><table width="100%" border="0" cellspacing="0" cellpadding="3">
                    <tr>
                      <td height="25" bgcolor="#ADC9AD" style="color: red; font-size: 18px" class="black12bold">HSC or Equivalent Level<span class="red12">*</span></td>
                    </tr>
                    <tr>
                      <td><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                        <tr>
                          <td width="37%" align="left" valign="middle">Examination</td>
                          <td width="63%" align="left" valign="middle"><select style="width:350px"  name="exam2" class="textfield06a" id="exam2">
                            <option selected="selected" value="0">Select One</option>
							<option value="1">H.S.C</option><option value="2">Alim</option><option value="3">Business Management</option><option value="4">Diploma</option><option value="5">A Level/Sr. Cambridge</option><option value="6">H.S.C Equivalent</option>
                          </select></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Board</td>
                          <td align="left" valign="middle"><select style="width:350px"  name="institute2" class="textfield06a" id="institute2">
                            <option selected="selected" value="0">Select One</option>
							<option value="1">Dhaka</option><option value="2">Comilla</option><option value="3">Rajshahi</option><option value="4">Jessore</option><option value="5">Chittagong</option><option value="6">Barisal</option><option value="7">Sylhet</option><option value="8">Dinajpur</option><option value="9">Madrasah</option><option value="10">Technical</option><option value="15">Cambridge International - IGCE</option><option value="16">Edexcel International</option><option value="20">Others</option>
                          </select></td>
                        </tr>
						<td height="25" align="left" valign="middle">Roll No</td>
                        <td height="25"align="left" valign="middle"><input style="width:350px"  name="roll2" type="text" class="textfield07b" id="roll2" onkeypress="return alpha(event,numbers)"/></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Result</td>
                          <td align="left" valign="middle"><table width="100%" border="0" cellpadding="0" cellspacing="1" class="black14" style="margin-bottom:1px;">
                            <tr>
                              <td width="55%" align="left" valign="middle"><select style="width:280px"  name="result2" class="textfield07" id="result2" onchange="Show_GpaTextBox(this.id,'result_gpa2');" >
                                <option value="0" selected="selected">Select</option>
								<option value="1">1st Division</option>
                                <option value="2">2nd Division</option>
                                <option value="3">3rd Division</option>
                                <option value="4">GPA(out of 4)</option>
								<option value="5">GPA(out of 5)</option>
                              </select>
                               <input type="text" style="width:60px" id="gpapont"/></td>
                             
							</tr>
                          </table></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Group</td>
                          <td align="left" valign="middle"><select style="width:350px"  name="subject2" class="textfield07" id="subject2">
                            <option selected="selected" value="0">Select One</option>
                            <option value="1">Science</option><option value="2">Humanities</option><option value="3">Commerce</option><option value="9">Others</option>
                          </select></td>
                        </tr>
                        <tr>
                          <td align="left" valign="middle">Passing Year</td>
                          <td align="left" valign="middle"><select style="width:350px" name="year2" class="textfield07" id="year2">
                            <option selected="selected" value="0">Select One</option>
                            <option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option>
                          </select></td>
                        </tr>
                      </table></td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td align="left" valign="middle" class="gap01">&nbsp;</td>
                  <td align="left" valign="middle" class="gap01">&nbsp;</td>
                </tr>
              </table></td>
              <td width="3%" align="left" valign="top">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" valign="top" class="bdr02"><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                <tr>
                  <td colspan="3" height="25" align="left" valign="middle" style="color: red; font-size: 18px"  bgcolor="#ADC9AD" class="black12bold">Graduation Level<span class="red12">*</span></td>
                  <td align="left" valign="middle" style="color: red; font-size: 18px" bgcolor="#ADC9AD" class="subblack14">&nbsp;</td>
                </tr>
                <tr>
                  <td width="19%" align="left" valign="top">Examination</td>
                  <td width="34%" align="left" valign="middle">
                    <select  name="exam3" style="width:300px" class="textfield06a" id="exam3" onchange="get_sub_gra(this), Show_ExamTextBox(this.id,'other_exam3'), changeVisibility3(this);">
                      <option  value="0" selected="selected">Select One</option>
                      <option value="1">B.Sc (Engineering/Architecture)</option><option value="2">B.Sc (Agricultural Science)</option><option value="3">M.B.B.S/B.D.S</option><option value="4">Honours</option><option value="5">Pass Course</option><option value="6">A & B Section of A.M.I.E</option><option value="9">Others</option>
                    </select>
					
                  </td>
                  <td width="17%" align="left" valign="top">Result</td>
                  <td width="30%" align="left" valign="top">
                    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="black14" style="margin-bottom:1px;">
                    <tr>
                      <td width="100%" align="left" valign="middle">
                        <select style="width:200px" name="result3" class="textfield07" id="result3" onchange="Show_GpaTextBox(this.id,'result_gpa3');" >
                          	<option value="0" selected="selected">Select One</option>
                          	<option value="1">1st Class</option>
							<option value="2">2nd Class</option>
							<option value="3">3rd Class</option>
							<option value="4">GPA/CGPA in scale 4</option>
							<option value="5">GPA/CGPA in scale 5</option>
							<option value="7">Pass</option>
                        </select><input type="text" style="width:88px" id="gpapont"/>
                      
                      </td>
                      
                    <td width="20%" align="left" valign="middle" id="Caption_Marks3" class="black11">&nbsp;</td>
					</tr>
                  </table>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">Subject/Degree <img src="images/loader.gif" border="0" align="absmiddle" name ="loading3" style="visibility:hidden"/></td>
                     <td align="left" valign="top">
                    <select style="width:300px" name="subject4" class="textfield06a" id="subject4" onchange="Show_SubTextBox(this.id,'other_subject4');"   >
                      <option selected="selected" value="0">Select One</option>
                      <option value="101">Accounting [101]</option><option value="102">Anthropology [102]</option><option value="103">Applied Chemistry [103]</option><option value="104">Applied Physics [104]</option><option value="105">Applied Mathematics [105]</option><option value="106">Arabic [106]</option><option value="107">Archaeology [107]</option><option value="108">Bangla [108]</option><option value="109">Banking [109]</option><option value="110">Biochemistry [110]</option><option value="111">Botany [111]</option><option value="112">Business Administration [112]</option><option value="113">Chemistry [113]</option><option value="114">Computer Science [114]</option><option value="115">Clinical Psychology [115]</option><option value="116">Drama & Music [116]</option><option value="117">Development Studies [117]</option><option value="118">Economics [118]</option><option value="119">Education [119]</option><option value="120">English [120]</option><option value="121">Finance [121]</option><option value="122">Fine Arts [122]</option><option value="123">Folklore [123]</option><option value="124">Geography [124]</option><option value="125">Geology [125]</option><option value="126">History [126]</option><option value="127">Home Economics [127]</option><option value="128">Hadith [128]</option><option value="129">International Relations [129]</option><option value="130">Islamic History and Culture [130]</option><option value="131">Islamic Studies [131]</option><option value="132">Information Com. Tech. (ICT) [132]</option><option value="133">Mass Comm. & Journalism [133]</option><option value="134">Law/Jurisprudence [134]</option><option value="135">Library & Information Science [135]</option><option value="136">Language/Linguistic [136]</option><option value="137">Management [137]</option><option value="138">Marketing [138]</option><option value="139">Mathematics [139]</option><option value="140">Microbiology [140]</option><option value="141">Marine Science [141]</option><option value="142">Medical Technology [142]</option><option value="143">Pali [143]</option><option value="144">Persian [144]</option><option value="145">Pharmacy [145]</option><option value="146">Philosophy [146]</option><option value="147">Physics [147]</option><option value="148">Political Science/Govt. and Politics [148]</option><option value="149">Psychology [149]</option><option value="150">Public Administration [150]</option><option value="151">Public Finance [151]</option><option value="152">Population Science [152]</option><option value="153">Peace & Conflict [153]</option><option value="154">Pharmaceutical Chemistry [154]</option><option value="155">Sanskrit [155]</option><option value="156">Social Welfare/Social Work [156]</option><option value="157">Sociology [157]</option><option value="158">Soil Water and Environment Science [158]</option><option value="159">Statistics [159]</option><option value="160">Tafsir [160]</option><option value="161">Urdu [161]</option><option value="162">Urban Development [162]</option><option value="163">World Religion [163]</option><option value="164">Women Studies [164]</option><option value="165">Water & Environment Science [165]</option><option value="166">Zoology [166]</option><option value="167">Genetic and Breeding [167]</option><option value="168">International Law [168]</option><option value="169">Akaid [169]</option><option value="170">Graphics [170]</option><option value="171">Fikha [171]</option><option value="172">Modern Arabic [172]</option><option value="173">History of Music [173]</option><option value="174">Drawing and Printing [174]</option><option value="175">Industrial Arts [175]</option><option value="176">Ethics [176]</option><option value="177">Forestry [177]</option><option value="178">Nursery School and Child Development [178]</option><option value="179">Child Development [179]</option><option value="180">Home Management and Housing [180]</option><option value="181">Food and Nutrition [181]</option><option value="182">Related Art [182]</option><option value="183">Clothing & Textile [183]</option><option value="184">Institutinal Food Management [184]</option><option value="185">Environmental Science [185]</option><option value="201">Agriculture [201]</option><option value="202">Agriculture Chemistry [202]</option><option value="203">Agriculture Co-operatives [203]</option><option value="204">Agriculture Economics [204]</option><option value="205">Agriculture Engineering [205]</option><option value="206">Agriculture Finance [206]</option><option value="207">Agriculture Marketing [207]</option><option value="208">Agriculture Science [208]</option><option value="209">Agriculture Soil Science [209]</option><option value="210">Animal Husbandry [210]</option><option value="211">Agronomy & Aquaculture [211]</option><option value="212">Agronomy & Aquaculture Extension [212]</option><option value="213">Anatomy & Histology [213]</option><option value="214">Agronnomy [214]</option><option value="215">Anatomology [215]</option><option value="216">Animal Breeding & Genetic [216]</option><option value="217">Animal Science [217]</option><option value="218">Animal Nutrition [218]</option><option value="220">Agriculture Water Management [220]</option><option value="221">Agriculture Extension [221]</option><option value="223">Agro Forestry [223]</option><option value="225">Agriculture Statistics [225]</option><option value="226">Agr.Co-operative & Marketing [226]</option><option value="227">Bio-Technology [227]</option><option value="228">Corp Botany [228]</option><option value="229">Dairy Science [229]</option><option value="230">Doc.of Veterinary Science [230]</option><option value="231">Fisheries [231]</option><option value="232">Fisheries & Aquaculture [232]</option><option value="233">Fisheries Biology [233]</option><option value="234">Fisheries Management [234]</option><option value="235">Fisheries Technology [235]</option><option value="236">Forestry [236]</option><option value="237">Farm Power & Machinery [237]</option><option value="238">Food Tech. & Rural Industry [238]</option><option value="239">Farm Structure [239]</option><option value="241">Horticulture [241]</option><option value="242">Livestock [242]</option><option value="243">Microbiology & Hygenic [243]</option><option value="244">Production Economics [244]</option><option value="245">Plant Pathology [245]</option><option value="246">Paratrology [246]</option><option value="247">Poultry Science [247]</option><option value="248">Rural Sociology [248]</option><option value="249">Surgery & Obstate [249]</option><option value="301">Architecture [301]</option><option value="302">Chemical [302]</option><option value="303">Civil [303]</option><option value="304">Computer [304]</option><option value="305">Electrical [305]</option><option value="306">Electrical & Electronics [306]</option><option value="307">Electronic [307]</option><option value="308">Genetic Engineering [308]</option><option value="309">Industrial [309]</option><option value="310">Leather Technology [310]</option><option value="311">Marine [311]</option><option value="312">Mechanical [312]</option><option value="313">Metallurgy [313]</option><option value="314">Mineral [314]</option><option value="315">Mining [315]</option><option value="316">Naval Architecture [316]</option><option value="317">Physical Planning [317]</option><option value="318">Regional Planning [318]</option><option value="319">Structural [319]</option><option value="320">Textile Technology [320]</option><option value="321">Town Planning [321]</option><option value="322">Urban Planning [322]</option><option value="323">Tele-Comunication Engineering [323]</option><option value="324">Computer Science & Engineering [324]</option><option value="325">Microwave Engineering [325]</option><option value="326">A & B Section of A.M.I.E [326]</option><option value="391">Medicine & Surgery [391]</option><option value="392">Dental Surgery [392]</option><option value="999">Others [999]</option>
                    </select>
					
                  </td>
                  <td align="left" valign="top">Passing Year</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="year3" class="textfield07" id="year3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">University/Institute</td>
                  <td align="left" valign="middle"><select style="width:300px" name="institute3" class="textfield06a" id="institute3" onchange="Show_UniTextBox(this.id,'other_institute3');">
                        <option value="0" selected="selected">Select One</option>
						<option value="111">Bangabandhu Sheikh Mujib Medical University</option><option value="112">Bangabandhu Sheikh Mujibur Rahman Agricultural University</option><option value="113">Bangladesh Agricultural University,Mymensingh</option><option value="114">Bangladesh Open University</option><option value="115">Bangladesh University of Engineering & Technology</option><option value="116">Bangladesh University of Professionals</option><option value="117">Chittagong University of Engineering & Technology</option><option value="118">Chittagong Veterinary and Animal Sciences University</option><option value="119">Comilla University</option><option value="120">Dhaka University</option><option value="121">Dhaka University of Engineering & Technology</option><option value="122">Hajee Mohammad Danesh Science & Technology University</option><option value="123">Islamic University</option><option value="124">Jagannath University</option><option value="125">Jahangirnagar University</option><option value="126">Jatiya Kabi Kazi Nazrul Islam University</option><option value="127">Jessore Science & Technology University</option><option value="128">Khulna University</option><option value="129">Khulna University of Engineering and Technology</option><option value="130">Mawlana Bhashani Science & Technology University</option><option value="131">National University</option><option value="132">Noakhali Science & Technology University</option><option value="133">Pabna University of Science and Technology</option><option value="134">Patuakhali Science And Technology University</option><option value="135">Rajshahi University</option><option value="136">Rajshahi University of Engineering & Technology</option><option value="137">Rangpur University</option><option value="138">Shahjalal University of Science & Technology</option><option value="139">Sher-e-Bangla Agricultural University</option><option value="140">Sylhet Agricultural University</option><option value="141">University of Chittagong</option><option value="222">Ahsanullah University of Science and Technology</option><option value="223">America Bangladesh University</option><option value="224">American International University Bangladesh</option><option value="225">ASA University Bangladesh</option><option value="226">Asian University of Bangladesh</option><option value="227">Atish Dipankar University of Science & Technology</option><option value="228">Bangladesh Islami University</option><option value="229">Bangladesh University</option><option value="230">Bangladesh University of Business & Technology (BUBT)</option><option value="231">BGC Trust University Bangladesh, Chittagong</option><option value="232">BRAC University</option><option value="233">Central Women's University</option><option value="234">City University</option><option value="235">Daffodil International University</option><option value="236">Darul Ihsan University</option><option value="237">Dhaka International University</option><option value="238">East Delta University , Chittagong</option><option value="239">East West University</option><option value="240">Eastern University</option><option value="241">Gono Bishwabidyalay</option><option value="242">Green University of Bangladesh</option><option value="243">IBAIS University</option><option value="244">Independent University, Bangladesh</option><option value="245">International Islamic University, Chittagong</option><option value="246">International University of Business Agriculture & Technology</option><option value="247">Leading University, Sylhet</option><option value="248">Manarat International University</option><option value="249">Metropolitan University, Sylhet</option><option value="250">North South University</option><option value="251">Northern University Bangladesh</option><option value="252">Premier University, Chittagong</option><option value="253">Presidency University</option><option value="254">Prime University</option><option value="255">Primeasia University</option><option value="256">Queens University</option><option value="257">Royal University of Dhaka</option><option value="258">Shanto Mariam University of Creative Technology</option><option value="259">Southeast University</option><option value="260">Southern University of Bangladesh , Chittagong</option><option value="261">Stamford University, Bangladesh</option><option value="262">State University Of Bangladesh</option><option value="263">Sylhet International University, Sylhet</option><option value="264">The Millenium University</option><option value="265">The Peoples University of Bangladesh</option><option value="266">The University of Asia Pacific</option><option value="267">United International University</option><option value="268">University of Development Alternative</option><option value="269">University of Information Technology & Sciences</option><option value="270">University of Liberal Arts Bangladesh</option><option value="271">University of Science & Technology, Chittagong</option><option value="272">University of South Asia</option><option value="273">Uttara University</option><option value="274">Victoria University of Bangladesh</option><option value="275">World University of Bangladesh</option><option value="333">Asian University for Women</option><option value="334">Islamic University of Technology</option><option value="335">South Asian University</option><option value="401">Dhaka Medical College</option><option value="402">Sir Salimullah Medical College</option><option value="403">Mymensingh Medical College</option><option value="404">Chittagong Medical College</option><option value="405">Rajshahi Medical College</option><option value="406">MAG Osmani Medical College</option><option value="407">Sher-E-Bangla Medical College</option><option value="408">Rangpur Medical College</option><option value="409">Comilla Medical College</option><option value="410">Khulna Medical College</option><option value="411">Shaheed Ziaur Rahman Medical College</option><option value="412">Dinajpur Medical College</option><option value="413">Faridpur Medical College</option><option value="414">Shaheed Suhrawardy Medical College</option><option value="415">Pabna Medical College</option><option value="416">Noakhali Medical College</option><option value="417">Cox's Bazar Medical College</option><option value="418">Jessore Medical College</option><option value="419">Shaheed Nazrul Islam Medical College</option><option value="420">Kushtia Medical College</option><option value="421">Satkhira Medical College</option><option value="422">Sheikh Sayera Khatun Medical College, Gopalganj</option><option value="501">Feni Medical College,Feni</option><option value="502">Gono Bishwabidyalay, Savar, Dhaka</option><option value="503">Ad-din Womens Medical College, Dhaka</option><option value="504">Anwer Khan Modern Medical College, Dhaka</option><option value="505">Bangladesh Medical College</option><option value="506">Jalalabad Rageb-Rabeya Medical College,Sylhet</option><option value="507">BGC Trust Medical College, Chittagong</option><option value="508">Central Medical College, Comilla</option><option value="509">Chottagram Ma-O-Shishu Hospital Medical College</option><option value="510">Community Based Medical College (cbmc), Mymensingh</option><option value="511">Community Medical College, Dhaka</option><option value="512">Delta Medical College, Dhaka</option><option value="513">Dhaka National Medical College</option><option value="514">Durra Samad Rahman Red Crescent Women�s Medical College, Sylhet</option><option value="515">Eastern Medical College, Comilla</option><option value="516">Enam Medical College, Savar, Dhaka</option><option value="517">Sylhet Women`s Medical College, Sylhet</option><option value="518">Green Life Medical College,Dhaka</option><option value="519">Holy Family Red Crescent Medical College, Dhaka</option><option value="520">Ibrahim Medical College, Dhaka</option><option value="521">Ibn Sina Medical College, Dhaka</option><option value="522">International Medical College, Gazipur</option><option value="523">Islami Bank Medical College, Rajshahi</option><option value="524">Jahurul Islam Medical College, Kishoregonj</option><option value="525">Jalalabad Ragib-Rabeya Medical College Sylhet</option><option value="526">Khawja Yunus Ali Medical College, Sirajganj</option><option value="527">Kumudini Medical College, Tangail</option><option value="528">Labaid Medical College[6] Dhanmondi, Dhaka</option><option value="529">Maulana Bhasani Medical College</option><option value="530">Medical College for Women and Hospital, Dhaka</option><option value="531">Nightingale Medical College, Dhaka</option><option value="532">North Bengal Medical College, Sirajganj</option><option value="533">North East Medical College, Sylhet</option><option value="534">Northern International Medical College, Dhaka</option><option value="535">Northern Private Medical College, Rangpur</option><option value="536">Popular Medical College & Hospital, Dhaka</option><option value="537">Prime Medical College, Rangpur</option><option value="538">Rangpur Community Hospital Medical College</option><option value="539">Sahabuddin Medical College and Hospital</option><option value="540">Samaj Vittik Medical College, Mirzanagar, Savar</option><option value="541">Shahabuddin Medical College, Dhaka</option><option value="542">Z. H. Sikder Women`s Medical College</option><option value="543">Southern Medical College, Chittagong</option><option value="544">Tairunnessa Memorial Medical College, Gazipur</option><option value="545">TMSS Medical College,Bogra</option><option value="546">University Of Science and Technology Chittagong. IAMS</option><option value="547">Uttara Adhunik Medical College,Dhaka</option><option value="999">Others</option>
                      </select>
					  <input name="other_institute3" type="text" class="textfield06" id="other_institute3" style="VISIBILITY: hidden" onkeypress="return alpha(event,letters)" /></td>
                  <td align="left" valign="top">Course Duration</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="duration3" class="textfield07" id="duration3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="01">01 Year</option>
                      <option value="02">02 Years</option>
                      <option value="03">03 Years</option>
                      <option value="04">04 Years</option>
                      <option value="05">05 Years</option>
                    </select>
                  </td>
                </tr>
              </table>
			  </td>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
			<tr>
              <td align="left" valign="top">&nbsp;</td>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" valign="top" class="bdr02"><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                <tr>
                     
                  <td colspan="3" height="25" style="color: red; font-size: 18px"  align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Masters Degree </td>
                  <td align="left" valign="middle" bgcolor="#ADC9AD" class="subblack14">&nbsp;</td>
                </tr>
            <tr>
                  <td width="19%" align="left" valign="top">Examination</td>
                  <td width="34%" align="left" valign="middle">
                    <select  name="exam3" style="width:300px" class="textfield06a" id="exam3" onchange="get_sub_gra(this), Show_ExamTextBox(this.id,'other_exam3'), changeVisibility3(this);">
                      <option  value="0" selected="selected">Select One</option>
                      <option value="1">B.Sc (Engineering/Architecture)</option><option value="2">B.Sc (Agricultural Science)</option><option value="3">M.B.B.S/B.D.S</option><option value="4">Honours</option><option value="5">Pass Course</option><option value="6">A & B Section of A.M.I.E</option><option value="9">Others</option>
                    </select>
					
                  </td>
                  <td width="17%" align="left" valign="top">Result</td>
                  <td width="30%" align="left" valign="top">
                    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="black14" style="margin-bottom:1px;">
                    <tr>
                      <td width="100%" align="left" valign="middle">
                        <select style="width:200px" name="result3" class="textfield07" id="result3" onchange="Show_GpaTextBox(this.id,'result_gpa3');" >
                          	<option value="0" selected="selected">Select One</option>
                          	<option value="1">1st Class</option>
							<option value="2">2nd Class</option>
							<option value="3">3rd Class</option>
							<option value="4">GPA/CGPA in scale 4</option>
							<option value="5">GPA/CGPA in scale 5</option>
							<option value="7">Pass</option>
                        </select><input type="text" style="width:88px" id="gpapont"/>
                      
                      </td>
                      
                    <td width="20%" align="left" valign="middle" id="Caption_Marks3" class="black11">&nbsp;</td>
					</tr>
                  </table>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">Subject/Degree <img src="images/loader.gif" border="0" align="absmiddle" name ="loading3" style="visibility:hidden"/></td>
                     <td align="left" valign="top">
                    <select style="width:300px" name="subject4" class="textfield06a" id="subject4" onchange="Show_SubTextBox(this.id,'other_subject4');"   >
                      <option selected="selected" value="0">Select One</option>
                      <option value="101">Accounting [101]</option><option value="102">Anthropology [102]</option><option value="103">Applied Chemistry [103]</option><option value="104">Applied Physics [104]</option><option value="105">Applied Mathematics [105]</option><option value="106">Arabic [106]</option><option value="107">Archaeology [107]</option><option value="108">Bangla [108]</option><option value="109">Banking [109]</option><option value="110">Biochemistry [110]</option><option value="111">Botany [111]</option><option value="112">Business Administration [112]</option><option value="113">Chemistry [113]</option><option value="114">Computer Science [114]</option><option value="115">Clinical Psychology [115]</option><option value="116">Drama & Music [116]</option><option value="117">Development Studies [117]</option><option value="118">Economics [118]</option><option value="119">Education [119]</option><option value="120">English [120]</option><option value="121">Finance [121]</option><option value="122">Fine Arts [122]</option><option value="123">Folklore [123]</option><option value="124">Geography [124]</option><option value="125">Geology [125]</option><option value="126">History [126]</option><option value="127">Home Economics [127]</option><option value="128">Hadith [128]</option><option value="129">International Relations [129]</option><option value="130">Islamic History and Culture [130]</option><option value="131">Islamic Studies [131]</option><option value="132">Information Com. Tech. (ICT) [132]</option><option value="133">Mass Comm. & Journalism [133]</option><option value="134">Law/Jurisprudence [134]</option><option value="135">Library & Information Science [135]</option><option value="136">Language/Linguistic [136]</option><option value="137">Management [137]</option><option value="138">Marketing [138]</option><option value="139">Mathematics [139]</option><option value="140">Microbiology [140]</option><option value="141">Marine Science [141]</option><option value="142">Medical Technology [142]</option><option value="143">Pali [143]</option><option value="144">Persian [144]</option><option value="145">Pharmacy [145]</option><option value="146">Philosophy [146]</option><option value="147">Physics [147]</option><option value="148">Political Science/Govt. and Politics [148]</option><option value="149">Psychology [149]</option><option value="150">Public Administration [150]</option><option value="151">Public Finance [151]</option><option value="152">Population Science [152]</option><option value="153">Peace & Conflict [153]</option><option value="154">Pharmaceutical Chemistry [154]</option><option value="155">Sanskrit [155]</option><option value="156">Social Welfare/Social Work [156]</option><option value="157">Sociology [157]</option><option value="158">Soil Water and Environment Science [158]</option><option value="159">Statistics [159]</option><option value="160">Tafsir [160]</option><option value="161">Urdu [161]</option><option value="162">Urban Development [162]</option><option value="163">World Religion [163]</option><option value="164">Women Studies [164]</option><option value="165">Water & Environment Science [165]</option><option value="166">Zoology [166]</option><option value="167">Genetic and Breeding [167]</option><option value="168">International Law [168]</option><option value="169">Akaid [169]</option><option value="170">Graphics [170]</option><option value="171">Fikha [171]</option><option value="172">Modern Arabic [172]</option><option value="173">History of Music [173]</option><option value="174">Drawing and Printing [174]</option><option value="175">Industrial Arts [175]</option><option value="176">Ethics [176]</option><option value="177">Forestry [177]</option><option value="178">Nursery School and Child Development [178]</option><option value="179">Child Development [179]</option><option value="180">Home Management and Housing [180]</option><option value="181">Food and Nutrition [181]</option><option value="182">Related Art [182]</option><option value="183">Clothing & Textile [183]</option><option value="184">Institutinal Food Management [184]</option><option value="185">Environmental Science [185]</option><option value="201">Agriculture [201]</option><option value="202">Agriculture Chemistry [202]</option><option value="203">Agriculture Co-operatives [203]</option><option value="204">Agriculture Economics [204]</option><option value="205">Agriculture Engineering [205]</option><option value="206">Agriculture Finance [206]</option><option value="207">Agriculture Marketing [207]</option><option value="208">Agriculture Science [208]</option><option value="209">Agriculture Soil Science [209]</option><option value="210">Animal Husbandry [210]</option><option value="211">Agronomy & Aquaculture [211]</option><option value="212">Agronomy & Aquaculture Extension [212]</option><option value="213">Anatomy & Histology [213]</option><option value="214">Agronnomy [214]</option><option value="215">Anatomology [215]</option><option value="216">Animal Breeding & Genetic [216]</option><option value="217">Animal Science [217]</option><option value="218">Animal Nutrition [218]</option><option value="220">Agriculture Water Management [220]</option><option value="221">Agriculture Extension [221]</option><option value="223">Agro Forestry [223]</option><option value="225">Agriculture Statistics [225]</option><option value="226">Agr.Co-operative & Marketing [226]</option><option value="227">Bio-Technology [227]</option><option value="228">Corp Botany [228]</option><option value="229">Dairy Science [229]</option><option value="230">Doc.of Veterinary Science [230]</option><option value="231">Fisheries [231]</option><option value="232">Fisheries & Aquaculture [232]</option><option value="233">Fisheries Biology [233]</option><option value="234">Fisheries Management [234]</option><option value="235">Fisheries Technology [235]</option><option value="236">Forestry [236]</option><option value="237">Farm Power & Machinery [237]</option><option value="238">Food Tech. & Rural Industry [238]</option><option value="239">Farm Structure [239]</option><option value="241">Horticulture [241]</option><option value="242">Livestock [242]</option><option value="243">Microbiology & Hygenic [243]</option><option value="244">Production Economics [244]</option><option value="245">Plant Pathology [245]</option><option value="246">Paratrology [246]</option><option value="247">Poultry Science [247]</option><option value="248">Rural Sociology [248]</option><option value="249">Surgery & Obstate [249]</option><option value="301">Architecture [301]</option><option value="302">Chemical [302]</option><option value="303">Civil [303]</option><option value="304">Computer [304]</option><option value="305">Electrical [305]</option><option value="306">Electrical & Electronics [306]</option><option value="307">Electronic [307]</option><option value="308">Genetic Engineering [308]</option><option value="309">Industrial [309]</option><option value="310">Leather Technology [310]</option><option value="311">Marine [311]</option><option value="312">Mechanical [312]</option><option value="313">Metallurgy [313]</option><option value="314">Mineral [314]</option><option value="315">Mining [315]</option><option value="316">Naval Architecture [316]</option><option value="317">Physical Planning [317]</option><option value="318">Regional Planning [318]</option><option value="319">Structural [319]</option><option value="320">Textile Technology [320]</option><option value="321">Town Planning [321]</option><option value="322">Urban Planning [322]</option><option value="323">Tele-Comunication Engineering [323]</option><option value="324">Computer Science & Engineering [324]</option><option value="325">Microwave Engineering [325]</option><option value="326">A & B Section of A.M.I.E [326]</option><option value="391">Medicine & Surgery [391]</option><option value="392">Dental Surgery [392]</option><option value="999">Others [999]</option>
                    </select>
					
                  </td>
                  <td align="left" valign="top">Passing Year</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="year3" class="textfield07" id="year3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">University/Institute</td>
                  <td align="left" valign="middle"><select style="width:300px" name="institute3" class="textfield06a" id="institute3" onchange="Show_UniTextBox(this.id,'other_institute3');">
                        <option value="0" selected="selected">Select One</option>
						<option value="111">Bangabandhu Sheikh Mujib Medical University</option><option value="112">Bangabandhu Sheikh Mujibur Rahman Agricultural University</option><option value="113">Bangladesh Agricultural University,Mymensingh</option><option value="114">Bangladesh Open University</option><option value="115">Bangladesh University of Engineering & Technology</option><option value="116">Bangladesh University of Professionals</option><option value="117">Chittagong University of Engineering & Technology</option><option value="118">Chittagong Veterinary and Animal Sciences University</option><option value="119">Comilla University</option><option value="120">Dhaka University</option><option value="121">Dhaka University of Engineering & Technology</option><option value="122">Hajee Mohammad Danesh Science & Technology University</option><option value="123">Islamic University</option><option value="124">Jagannath University</option><option value="125">Jahangirnagar University</option><option value="126">Jatiya Kabi Kazi Nazrul Islam University</option><option value="127">Jessore Science & Technology University</option><option value="128">Khulna University</option><option value="129">Khulna University of Engineering and Technology</option><option value="130">Mawlana Bhashani Science & Technology University</option><option value="131">National University</option><option value="132">Noakhali Science & Technology University</option><option value="133">Pabna University of Science and Technology</option><option value="134">Patuakhali Science And Technology University</option><option value="135">Rajshahi University</option><option value="136">Rajshahi University of Engineering & Technology</option><option value="137">Rangpur University</option><option value="138">Shahjalal University of Science & Technology</option><option value="139">Sher-e-Bangla Agricultural University</option><option value="140">Sylhet Agricultural University</option><option value="141">University of Chittagong</option><option value="222">Ahsanullah University of Science and Technology</option><option value="223">America Bangladesh University</option><option value="224">American International University Bangladesh</option><option value="225">ASA University Bangladesh</option><option value="226">Asian University of Bangladesh</option><option value="227">Atish Dipankar University of Science & Technology</option><option value="228">Bangladesh Islami University</option><option value="229">Bangladesh University</option><option value="230">Bangladesh University of Business & Technology (BUBT)</option><option value="231">BGC Trust University Bangladesh, Chittagong</option><option value="232">BRAC University</option><option value="233">Central Women's University</option><option value="234">City University</option><option value="235">Daffodil International University</option><option value="236">Darul Ihsan University</option><option value="237">Dhaka International University</option><option value="238">East Delta University , Chittagong</option><option value="239">East West University</option><option value="240">Eastern University</option><option value="241">Gono Bishwabidyalay</option><option value="242">Green University of Bangladesh</option><option value="243">IBAIS University</option><option value="244">Independent University, Bangladesh</option><option value="245">International Islamic University, Chittagong</option><option value="246">International University of Business Agriculture & Technology</option><option value="247">Leading University, Sylhet</option><option value="248">Manarat International University</option><option value="249">Metropolitan University, Sylhet</option><option value="250">North South University</option><option value="251">Northern University Bangladesh</option><option value="252">Premier University, Chittagong</option><option value="253">Presidency University</option><option value="254">Prime University</option><option value="255">Primeasia University</option><option value="256">Queens University</option><option value="257">Royal University of Dhaka</option><option value="258">Shanto Mariam University of Creative Technology</option><option value="259">Southeast University</option><option value="260">Southern University of Bangladesh , Chittagong</option><option value="261">Stamford University, Bangladesh</option><option value="262">State University Of Bangladesh</option><option value="263">Sylhet International University, Sylhet</option><option value="264">The Millenium University</option><option value="265">The Peoples University of Bangladesh</option><option value="266">The University of Asia Pacific</option><option value="267">United International University</option><option value="268">University of Development Alternative</option><option value="269">University of Information Technology & Sciences</option><option value="270">University of Liberal Arts Bangladesh</option><option value="271">University of Science & Technology, Chittagong</option><option value="272">University of South Asia</option><option value="273">Uttara University</option><option value="274">Victoria University of Bangladesh</option><option value="275">World University of Bangladesh</option><option value="333">Asian University for Women</option><option value="334">Islamic University of Technology</option><option value="335">South Asian University</option><option value="401">Dhaka Medical College</option><option value="402">Sir Salimullah Medical College</option><option value="403">Mymensingh Medical College</option><option value="404">Chittagong Medical College</option><option value="405">Rajshahi Medical College</option><option value="406">MAG Osmani Medical College</option><option value="407">Sher-E-Bangla Medical College</option><option value="408">Rangpur Medical College</option><option value="409">Comilla Medical College</option><option value="410">Khulna Medical College</option><option value="411">Shaheed Ziaur Rahman Medical College</option><option value="412">Dinajpur Medical College</option><option value="413">Faridpur Medical College</option><option value="414">Shaheed Suhrawardy Medical College</option><option value="415">Pabna Medical College</option><option value="416">Noakhali Medical College</option><option value="417">Cox's Bazar Medical College</option><option value="418">Jessore Medical College</option><option value="419">Shaheed Nazrul Islam Medical College</option><option value="420">Kushtia Medical College</option><option value="421">Satkhira Medical College</option><option value="422">Sheikh Sayera Khatun Medical College, Gopalganj</option><option value="501">Feni Medical College,Feni</option><option value="502">Gono Bishwabidyalay, Savar, Dhaka</option><option value="503">Ad-din Womens Medical College, Dhaka</option><option value="504">Anwer Khan Modern Medical College, Dhaka</option><option value="505">Bangladesh Medical College</option><option value="506">Jalalabad Rageb-Rabeya Medical College,Sylhet</option><option value="507">BGC Trust Medical College, Chittagong</option><option value="508">Central Medical College, Comilla</option><option value="509">Chottagram Ma-O-Shishu Hospital Medical College</option><option value="510">Community Based Medical College (cbmc), Mymensingh</option><option value="511">Community Medical College, Dhaka</option><option value="512">Delta Medical College, Dhaka</option><option value="513">Dhaka National Medical College</option><option value="514">Durra Samad Rahman Red Crescent Women�s Medical College, Sylhet</option><option value="515">Eastern Medical College, Comilla</option><option value="516">Enam Medical College, Savar, Dhaka</option><option value="517">Sylhet Women`s Medical College, Sylhet</option><option value="518">Green Life Medical College,Dhaka</option><option value="519">Holy Family Red Crescent Medical College, Dhaka</option><option value="520">Ibrahim Medical College, Dhaka</option><option value="521">Ibn Sina Medical College, Dhaka</option><option value="522">International Medical College, Gazipur</option><option value="523">Islami Bank Medical College, Rajshahi</option><option value="524">Jahurul Islam Medical College, Kishoregonj</option><option value="525">Jalalabad Ragib-Rabeya Medical College Sylhet</option><option value="526">Khawja Yunus Ali Medical College, Sirajganj</option><option value="527">Kumudini Medical College, Tangail</option><option value="528">Labaid Medical College[6] Dhanmondi, Dhaka</option><option value="529">Maulana Bhasani Medical College</option><option value="530">Medical College for Women and Hospital, Dhaka</option><option value="531">Nightingale Medical College, Dhaka</option><option value="532">North Bengal Medical College, Sirajganj</option><option value="533">North East Medical College, Sylhet</option><option value="534">Northern International Medical College, Dhaka</option><option value="535">Northern Private Medical College, Rangpur</option><option value="536">Popular Medical College & Hospital, Dhaka</option><option value="537">Prime Medical College, Rangpur</option><option value="538">Rangpur Community Hospital Medical College</option><option value="539">Sahabuddin Medical College and Hospital</option><option value="540">Samaj Vittik Medical College, Mirzanagar, Savar</option><option value="541">Shahabuddin Medical College, Dhaka</option><option value="542">Z. H. Sikder Women`s Medical College</option><option value="543">Southern Medical College, Chittagong</option><option value="544">Tairunnessa Memorial Medical College, Gazipur</option><option value="545">TMSS Medical College,Bogra</option><option value="546">University Of Science and Technology Chittagong. IAMS</option><option value="547">Uttara Adhunik Medical College,Dhaka</option><option value="999">Others</option>
                      </select>
					  <input name="other_institute3" type="text" class="textfield06" id="other_institute3" style="VISIBILITY: hidden" onkeypress="return alpha(event,letters)" /></td>
                  <td align="left" valign="top">Course Duration</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="duration3" class="textfield07" id="duration3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="01">01 Year</option>
                      <option value="02">02 Years</option>
                      <option value="03">03 Years</option>
                      <option value="04">04 Years</option>
                      <option value="05">05 Years</option>
                    </select>
                  </td>
                </tr>
              </table></td>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
                <tr>
              <td align="left" valign="top" class="bdr02"><table width="100%" border="0" cellpadding="3" cellspacing="0" class="black12">
                <tr>
                     
                  <td colspan="3" height="25" style="color: red; font-size: 18px"  align="left" valign="middle" bgcolor="#ADC9AD" class="black12bold">Mphil/ Phd </td>
                  <td align="left" valign="middle" bgcolor="#ADC9AD" class="subblack14">&nbsp;</td>
                </tr>
              <tr>
                  <td width="19%" align="left" valign="top">Examination</td>
                  <td width="34%" align="left" valign="middle">
                    <select  name="exam3" style="width:300px" class="textfield06a" id="exam3" onchange="get_sub_gra(this), Show_ExamTextBox(this.id,'other_exam3'), changeVisibility3(this);">
                      <option  value="0" selected="selected">Select One</option>
                      <option value="1">B.Sc (Engineering/Architecture)</option><option value="2">B.Sc (Agricultural Science)</option><option value="3">M.B.B.S/B.D.S</option><option value="4">Honours</option><option value="5">Pass Course</option><option value="6">A & B Section of A.M.I.E</option><option value="9">Others</option>
                    </select>
					
                  </td>
                  <td width="17%" align="left" valign="top">Result</td>
                  <td width="30%" align="left" valign="top">
                    <table width="100%" border="0" cellpadding="0" cellspacing="1" class="black14" style="margin-bottom:1px;">
                    <tr>
                      <td width="100%" align="left" valign="middle">
                        <select style="width:200px" name="result3" class="textfield07" id="result3" onchange="Show_GpaTextBox(this.id,'result_gpa3');" >
                          	<option value="0" selected="selected">Select One</option>
                          	<option value="1">1st Class</option>
							<option value="2">2nd Class</option>
							<option value="3">3rd Class</option>
							<option value="4">GPA/CGPA in scale 4</option>
							<option value="5">GPA/CGPA in scale 5</option>
							<option value="7">Pass</option>
                        </select><input type="text" style="width:88px" id="gpapont"/>
                      
                      </td>
                      
                    <td width="20%" align="left" valign="middle" id="Caption_Marks3" class="black11">&nbsp;</td>
					</tr>
                  </table>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">Subject/Degree <img src="images/loader.gif" border="0" align="absmiddle" name ="loading3" style="visibility:hidden"/></td>
                     <td align="left" valign="top">
                    <select style="width:300px" name="subject4" class="textfield06a" id="subject4" onchange="Show_SubTextBox(this.id,'other_subject4');"   >
                      <option selected="selected" value="0">Select One</option>
                      <option value="101">Accounting [101]</option><option value="102">Anthropology [102]</option><option value="103">Applied Chemistry [103]</option><option value="104">Applied Physics [104]</option><option value="105">Applied Mathematics [105]</option><option value="106">Arabic [106]</option><option value="107">Archaeology [107]</option><option value="108">Bangla [108]</option><option value="109">Banking [109]</option><option value="110">Biochemistry [110]</option><option value="111">Botany [111]</option><option value="112">Business Administration [112]</option><option value="113">Chemistry [113]</option><option value="114">Computer Science [114]</option><option value="115">Clinical Psychology [115]</option><option value="116">Drama & Music [116]</option><option value="117">Development Studies [117]</option><option value="118">Economics [118]</option><option value="119">Education [119]</option><option value="120">English [120]</option><option value="121">Finance [121]</option><option value="122">Fine Arts [122]</option><option value="123">Folklore [123]</option><option value="124">Geography [124]</option><option value="125">Geology [125]</option><option value="126">History [126]</option><option value="127">Home Economics [127]</option><option value="128">Hadith [128]</option><option value="129">International Relations [129]</option><option value="130">Islamic History and Culture [130]</option><option value="131">Islamic Studies [131]</option><option value="132">Information Com. Tech. (ICT) [132]</option><option value="133">Mass Comm. & Journalism [133]</option><option value="134">Law/Jurisprudence [134]</option><option value="135">Library & Information Science [135]</option><option value="136">Language/Linguistic [136]</option><option value="137">Management [137]</option><option value="138">Marketing [138]</option><option value="139">Mathematics [139]</option><option value="140">Microbiology [140]</option><option value="141">Marine Science [141]</option><option value="142">Medical Technology [142]</option><option value="143">Pali [143]</option><option value="144">Persian [144]</option><option value="145">Pharmacy [145]</option><option value="146">Philosophy [146]</option><option value="147">Physics [147]</option><option value="148">Political Science/Govt. and Politics [148]</option><option value="149">Psychology [149]</option><option value="150">Public Administration [150]</option><option value="151">Public Finance [151]</option><option value="152">Population Science [152]</option><option value="153">Peace & Conflict [153]</option><option value="154">Pharmaceutical Chemistry [154]</option><option value="155">Sanskrit [155]</option><option value="156">Social Welfare/Social Work [156]</option><option value="157">Sociology [157]</option><option value="158">Soil Water and Environment Science [158]</option><option value="159">Statistics [159]</option><option value="160">Tafsir [160]</option><option value="161">Urdu [161]</option><option value="162">Urban Development [162]</option><option value="163">World Religion [163]</option><option value="164">Women Studies [164]</option><option value="165">Water & Environment Science [165]</option><option value="166">Zoology [166]</option><option value="167">Genetic and Breeding [167]</option><option value="168">International Law [168]</option><option value="169">Akaid [169]</option><option value="170">Graphics [170]</option><option value="171">Fikha [171]</option><option value="172">Modern Arabic [172]</option><option value="173">History of Music [173]</option><option value="174">Drawing and Printing [174]</option><option value="175">Industrial Arts [175]</option><option value="176">Ethics [176]</option><option value="177">Forestry [177]</option><option value="178">Nursery School and Child Development [178]</option><option value="179">Child Development [179]</option><option value="180">Home Management and Housing [180]</option><option value="181">Food and Nutrition [181]</option><option value="182">Related Art [182]</option><option value="183">Clothing & Textile [183]</option><option value="184">Institutinal Food Management [184]</option><option value="185">Environmental Science [185]</option><option value="201">Agriculture [201]</option><option value="202">Agriculture Chemistry [202]</option><option value="203">Agriculture Co-operatives [203]</option><option value="204">Agriculture Economics [204]</option><option value="205">Agriculture Engineering [205]</option><option value="206">Agriculture Finance [206]</option><option value="207">Agriculture Marketing [207]</option><option value="208">Agriculture Science [208]</option><option value="209">Agriculture Soil Science [209]</option><option value="210">Animal Husbandry [210]</option><option value="211">Agronomy & Aquaculture [211]</option><option value="212">Agronomy & Aquaculture Extension [212]</option><option value="213">Anatomy & Histology [213]</option><option value="214">Agronnomy [214]</option><option value="215">Anatomology [215]</option><option value="216">Animal Breeding & Genetic [216]</option><option value="217">Animal Science [217]</option><option value="218">Animal Nutrition [218]</option><option value="220">Agriculture Water Management [220]</option><option value="221">Agriculture Extension [221]</option><option value="223">Agro Forestry [223]</option><option value="225">Agriculture Statistics [225]</option><option value="226">Agr.Co-operative & Marketing [226]</option><option value="227">Bio-Technology [227]</option><option value="228">Corp Botany [228]</option><option value="229">Dairy Science [229]</option><option value="230">Doc.of Veterinary Science [230]</option><option value="231">Fisheries [231]</option><option value="232">Fisheries & Aquaculture [232]</option><option value="233">Fisheries Biology [233]</option><option value="234">Fisheries Management [234]</option><option value="235">Fisheries Technology [235]</option><option value="236">Forestry [236]</option><option value="237">Farm Power & Machinery [237]</option><option value="238">Food Tech. & Rural Industry [238]</option><option value="239">Farm Structure [239]</option><option value="241">Horticulture [241]</option><option value="242">Livestock [242]</option><option value="243">Microbiology & Hygenic [243]</option><option value="244">Production Economics [244]</option><option value="245">Plant Pathology [245]</option><option value="246">Paratrology [246]</option><option value="247">Poultry Science [247]</option><option value="248">Rural Sociology [248]</option><option value="249">Surgery & Obstate [249]</option><option value="301">Architecture [301]</option><option value="302">Chemical [302]</option><option value="303">Civil [303]</option><option value="304">Computer [304]</option><option value="305">Electrical [305]</option><option value="306">Electrical & Electronics [306]</option><option value="307">Electronic [307]</option><option value="308">Genetic Engineering [308]</option><option value="309">Industrial [309]</option><option value="310">Leather Technology [310]</option><option value="311">Marine [311]</option><option value="312">Mechanical [312]</option><option value="313">Metallurgy [313]</option><option value="314">Mineral [314]</option><option value="315">Mining [315]</option><option value="316">Naval Architecture [316]</option><option value="317">Physical Planning [317]</option><option value="318">Regional Planning [318]</option><option value="319">Structural [319]</option><option value="320">Textile Technology [320]</option><option value="321">Town Planning [321]</option><option value="322">Urban Planning [322]</option><option value="323">Tele-Comunication Engineering [323]</option><option value="324">Computer Science & Engineering [324]</option><option value="325">Microwave Engineering [325]</option><option value="326">A & B Section of A.M.I.E [326]</option><option value="391">Medicine & Surgery [391]</option><option value="392">Dental Surgery [392]</option><option value="999">Others [999]</option>
                    </select>
					
                  </td>
                  <td align="left" valign="top">Passing Year</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="year3" class="textfield07" id="year3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td align="left" valign="top">University/Institute</td>
                  <td align="left" valign="middle"><select style="width:300px" name="institute3" class="textfield06a" id="institute3" onchange="Show_UniTextBox(this.id,'other_institute3');">
                        <option value="0" selected="selected">Select One</option>
						<option value="111">Bangabandhu Sheikh Mujib Medical University</option><option value="112">Bangabandhu Sheikh Mujibur Rahman Agricultural University</option><option value="113">Bangladesh Agricultural University,Mymensingh</option><option value="114">Bangladesh Open University</option><option value="115">Bangladesh University of Engineering & Technology</option><option value="116">Bangladesh University of Professionals</option><option value="117">Chittagong University of Engineering & Technology</option><option value="118">Chittagong Veterinary and Animal Sciences University</option><option value="119">Comilla University</option><option value="120">Dhaka University</option><option value="121">Dhaka University of Engineering & Technology</option><option value="122">Hajee Mohammad Danesh Science & Technology University</option><option value="123">Islamic University</option><option value="124">Jagannath University</option><option value="125">Jahangirnagar University</option><option value="126">Jatiya Kabi Kazi Nazrul Islam University</option><option value="127">Jessore Science & Technology University</option><option value="128">Khulna University</option><option value="129">Khulna University of Engineering and Technology</option><option value="130">Mawlana Bhashani Science & Technology University</option><option value="131">National University</option><option value="132">Noakhali Science & Technology University</option><option value="133">Pabna University of Science and Technology</option><option value="134">Patuakhali Science And Technology University</option><option value="135">Rajshahi University</option><option value="136">Rajshahi University of Engineering & Technology</option><option value="137">Rangpur University</option><option value="138">Shahjalal University of Science & Technology</option><option value="139">Sher-e-Bangla Agricultural University</option><option value="140">Sylhet Agricultural University</option><option value="141">University of Chittagong</option><option value="222">Ahsanullah University of Science and Technology</option><option value="223">America Bangladesh University</option><option value="224">American International University Bangladesh</option><option value="225">ASA University Bangladesh</option><option value="226">Asian University of Bangladesh</option><option value="227">Atish Dipankar University of Science & Technology</option><option value="228">Bangladesh Islami University</option><option value="229">Bangladesh University</option><option value="230">Bangladesh University of Business & Technology (BUBT)</option><option value="231">BGC Trust University Bangladesh, Chittagong</option><option value="232">BRAC University</option><option value="233">Central Women's University</option><option value="234">City University</option><option value="235">Daffodil International University</option><option value="236">Darul Ihsan University</option><option value="237">Dhaka International University</option><option value="238">East Delta University , Chittagong</option><option value="239">East West University</option><option value="240">Eastern University</option><option value="241">Gono Bishwabidyalay</option><option value="242">Green University of Bangladesh</option><option value="243">IBAIS University</option><option value="244">Independent University, Bangladesh</option><option value="245">International Islamic University, Chittagong</option><option value="246">International University of Business Agriculture & Technology</option><option value="247">Leading University, Sylhet</option><option value="248">Manarat International University</option><option value="249">Metropolitan University, Sylhet</option><option value="250">North South University</option><option value="251">Northern University Bangladesh</option><option value="252">Premier University, Chittagong</option><option value="253">Presidency University</option><option value="254">Prime University</option><option value="255">Primeasia University</option><option value="256">Queens University</option><option value="257">Royal University of Dhaka</option><option value="258">Shanto Mariam University of Creative Technology</option><option value="259">Southeast University</option><option value="260">Southern University of Bangladesh , Chittagong</option><option value="261">Stamford University, Bangladesh</option><option value="262">State University Of Bangladesh</option><option value="263">Sylhet International University, Sylhet</option><option value="264">The Millenium University</option><option value="265">The Peoples University of Bangladesh</option><option value="266">The University of Asia Pacific</option><option value="267">United International University</option><option value="268">University of Development Alternative</option><option value="269">University of Information Technology & Sciences</option><option value="270">University of Liberal Arts Bangladesh</option><option value="271">University of Science & Technology, Chittagong</option><option value="272">University of South Asia</option><option value="273">Uttara University</option><option value="274">Victoria University of Bangladesh</option><option value="275">World University of Bangladesh</option><option value="333">Asian University for Women</option><option value="334">Islamic University of Technology</option><option value="335">South Asian University</option><option value="401">Dhaka Medical College</option><option value="402">Sir Salimullah Medical College</option><option value="403">Mymensingh Medical College</option><option value="404">Chittagong Medical College</option><option value="405">Rajshahi Medical College</option><option value="406">MAG Osmani Medical College</option><option value="407">Sher-E-Bangla Medical College</option><option value="408">Rangpur Medical College</option><option value="409">Comilla Medical College</option><option value="410">Khulna Medical College</option><option value="411">Shaheed Ziaur Rahman Medical College</option><option value="412">Dinajpur Medical College</option><option value="413">Faridpur Medical College</option><option value="414">Shaheed Suhrawardy Medical College</option><option value="415">Pabna Medical College</option><option value="416">Noakhali Medical College</option><option value="417">Cox's Bazar Medical College</option><option value="418">Jessore Medical College</option><option value="419">Shaheed Nazrul Islam Medical College</option><option value="420">Kushtia Medical College</option><option value="421">Satkhira Medical College</option><option value="422">Sheikh Sayera Khatun Medical College, Gopalganj</option><option value="501">Feni Medical College,Feni</option><option value="502">Gono Bishwabidyalay, Savar, Dhaka</option><option value="503">Ad-din Womens Medical College, Dhaka</option><option value="504">Anwer Khan Modern Medical College, Dhaka</option><option value="505">Bangladesh Medical College</option><option value="506">Jalalabad Rageb-Rabeya Medical College,Sylhet</option><option value="507">BGC Trust Medical College, Chittagong</option><option value="508">Central Medical College, Comilla</option><option value="509">Chottagram Ma-O-Shishu Hospital Medical College</option><option value="510">Community Based Medical College (cbmc), Mymensingh</option><option value="511">Community Medical College, Dhaka</option><option value="512">Delta Medical College, Dhaka</option><option value="513">Dhaka National Medical College</option><option value="514">Durra Samad Rahman Red Crescent Women�s Medical College, Sylhet</option><option value="515">Eastern Medical College, Comilla</option><option value="516">Enam Medical College, Savar, Dhaka</option><option value="517">Sylhet Women`s Medical College, Sylhet</option><option value="518">Green Life Medical College,Dhaka</option><option value="519">Holy Family Red Crescent Medical College, Dhaka</option><option value="520">Ibrahim Medical College, Dhaka</option><option value="521">Ibn Sina Medical College, Dhaka</option><option value="522">International Medical College, Gazipur</option><option value="523">Islami Bank Medical College, Rajshahi</option><option value="524">Jahurul Islam Medical College, Kishoregonj</option><option value="525">Jalalabad Ragib-Rabeya Medical College Sylhet</option><option value="526">Khawja Yunus Ali Medical College, Sirajganj</option><option value="527">Kumudini Medical College, Tangail</option><option value="528">Labaid Medical College[6] Dhanmondi, Dhaka</option><option value="529">Maulana Bhasani Medical College</option><option value="530">Medical College for Women and Hospital, Dhaka</option><option value="531">Nightingale Medical College, Dhaka</option><option value="532">North Bengal Medical College, Sirajganj</option><option value="533">North East Medical College, Sylhet</option><option value="534">Northern International Medical College, Dhaka</option><option value="535">Northern Private Medical College, Rangpur</option><option value="536">Popular Medical College & Hospital, Dhaka</option><option value="537">Prime Medical College, Rangpur</option><option value="538">Rangpur Community Hospital Medical College</option><option value="539">Sahabuddin Medical College and Hospital</option><option value="540">Samaj Vittik Medical College, Mirzanagar, Savar</option><option value="541">Shahabuddin Medical College, Dhaka</option><option value="542">Z. H. Sikder Women`s Medical College</option><option value="543">Southern Medical College, Chittagong</option><option value="544">Tairunnessa Memorial Medical College, Gazipur</option><option value="545">TMSS Medical College,Bogra</option><option value="546">University Of Science and Technology Chittagong. IAMS</option><option value="547">Uttara Adhunik Medical College,Dhaka</option><option value="999">Others</option>
                      </select>
					  <input name="other_institute3" type="text" class="textfield06" id="other_institute3" style="VISIBILITY: hidden" onkeypress="return alpha(event,letters)" /></td>
                  <td align="left" valign="top">Course Duration</td>
                  <td align="left" valign="top">
                    <select style="width:300px" name="duration3" class="textfield07" id="duration3">
                      <option selected="selected" value="0">Select One</option>
                      <option value="01">01 Year</option>
                      <option value="02">02 Years</option>
                      <option value="03">03 Years</option>
                      <option value="04">04 Years</option>
                      <option value="05">05 Years</option>
                    </select>
                  </td>
                </tr>
              </table></td>
              <td align="left" valign="top">&nbsp;</td>
            </tr>
			
          </table></td>
        </tr>
    </table>
                                                
                                                <div class="form-actions">
                                                    <button class="btn btn-info" type="submit">
                                                        <i class="icon-ok bigger-110"></i>
                                                        Submit
                                                    </button>
                    
                                                    &nbsp; &nbsp; &nbsp;
                                                    <button class="btn" type="reset">
                                                        <i class="icon-undo bigger-110"></i>
                                                        Reset
                                                    </button>
                                                </div>
                                            </form>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div><!--/widget-main-->
                        </div><!--/widget-body-->
                    </div>
                </div>
            </div>

            <!--PAGE CONTENT ENDS HERE-->
        </div><!--/row-->
    </div><!--/#page-content-->

 
</div><!--/#main-content-->
<style>
.errorSummary ul li{
	color:#F00;
}
.lighter{
	width:98%;
}
</style>
<script type="text/javascript">
	  $(document).ready(function () {
    $('#datetimepicker').datepicker({
      format: "dd/mm/yyyy",
      language: 'en-GB',
    });

    $('.dp').on('change', function(){
        $('.datepicker').hide();
    });

});	
</script>