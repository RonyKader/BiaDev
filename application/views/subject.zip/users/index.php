			<div id="main-content" class="clearfix">
				<div id="breadcrumbs">
					<ul class="breadcrumb">
						<li>
							<i class="icon-home"></i>
							<a href="<?php echo site_url();?>">Home</a>

							<span class="divider">
								<i class="icon-angle-right"></i>
							</span>
						</li>
						<li class="active">Users</li>
					</ul><!--.breadcrumb-->

					
				</div>

				<div id="page-content" class="clearfix">
					

					<div class="row-fluid">
						<!--PAGE CONTENT BEGINS HERE-->
						<div class="row-fluid">
                        	  <?php if($this->session->flashdata('success')){?>
                            <div class="alert alert-block alert-success">
									<p>
										<strong>
											<i class="icon-ok"></i>
											Success!
										</strong>
										<?php echo $this->session->flashdata('success');?>
									</p>
							</div>
                            <?php }?>
							<h3 class="header smaller lighter blue">Manage Users</h3>
                            
							<div class="table-header">
								Results for "Users"
							</div>

							<table id="user_list" class="table table-striped table-bordered table-hover">
								<thead>
									<tr>
										<th class="center">id</th>
										<th>Username</th>
                                        <th>Created</th>
                                        <th>Updated</th>
                                        <th>Actions</th>
									</tr>
								</thead>
							</table>
						</div>

						<!--PAGE CONTENT ENDS HERE-->
					</div><!--/row-->
				</div><!--/#page-content-->

				<div id="ace-settings-container">
					<div class="btn btn-app btn-mini btn-warning" id="ace-settings-btn">
						<i class="icon-cog"></i>
					</div>

					<div id="ace-settings-box">
						<div>
							<div class="pull-left">
								<select id="skin-colorpicker" class="hidden">
									<option data-class="default" value="#438EB9">#438EB9</option>
									<option data-class="skin-1" value="#222A2D">#222A2D</option>
									<option data-class="skin-2" value="#C6487E">#C6487E</option>
									<option data-class="skin-3" value="#D0D0D0">#D0D0D0</option>
								</select>
							</div>
							<span>&nbsp; Choose Skin</span>
						</div>

						<div>
							<input type="checkbox" class="ace-checkbox-2" id="ace-settings-header" />
							<label class="lbl" for="ace-settings-header"> Fixed Header</label>
						</div>

						<div>
							<input type="checkbox" class="ace-checkbox-2" id="ace-settings-sidebar" />
							<label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
						</div>
					</div>
				</div><!--/#ace-settings-container-->
			</div><!--/#main-content-->
		</div><!--/.fluid-container#main-container-->
<script type="text/javascript">
	$(document).ready(function() {
		$('#user_list').dataTable( {
			"aoColumnDefs": [
				  { 'bSortable': false, 'aTargets': [4 ] }
				],
			 "iDisplayLength": 50,
			"bProcessing": true,
			"bServerSide": true,
			"sAjaxSource": "<?php echo site_url('users/get');?>",
			"bDeferRender": true
		}); 
	}); 
function confirm_status() {
	var agree = confirm("Are you sure, you want to delete this user?");
	if (!agree) return false;
}
</script>        
        